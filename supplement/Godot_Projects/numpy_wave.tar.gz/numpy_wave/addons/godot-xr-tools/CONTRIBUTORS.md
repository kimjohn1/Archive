Contributors
============

The main author of this project is [Bastiaan Olij](https://github.com/BastiaanOlij) who manages the source repository found at:
https://github.com/GodotVR/godot-xr-tools

Other people who have helped out by submitting fixes, enhancements, etc are:
- [Florian Jung](https://github.com/Windfisch)
- [RMKD](https://github.com/RMKD)
- [Alessandro Schillaci](https://github.com/silverslade)
- [jtank4](https://github.com/jtank4)
- [Malcolm Nixon](https://github.com/malcolmnixon)
- [Sam Sarette](https://github.com/lunarcloud)
- [Henodude](https://github.com/Henodude)
- [Miodrag Sejic](https://github.com/DigitalN8m4r3)
- [Carlos Padial](https://github.com/surreal6)
- [Julian Todd](https://github.com/goatchurchprime)
- [Kai Tödter](https://github.com/toedter)
- [Sam Sarette](https://github.com/lunarcloud)

Want to be on this list? We would love your help.
